﻿using System;

namespace HotelProyecto
{
    class Alimentos :Cliente
    {
        public Alimentos (string comida, int precio)
        {
            this.Comida = comida;
            this.Precio = precio;
        }
    }
}
