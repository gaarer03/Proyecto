﻿namespace HotelProyecto
{


    partial class HabitacionesDataSet
    {
    }
}

namespace HotelProyecto.HabitacionesDataSetTableAdapters {
    
    
    public partial class HabitaciónTableAdapter {
    }
}
