﻿namespace HotelProyecto
{
    partial class FormCheck_In
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCheck_In));
            this.cmbNumPersonas = new System.Windows.Forms.ComboBox();
            this.lbNumNoches = new System.Windows.Forms.Label();
            this.lbNumPersonas = new System.Windows.Forms.Label();
            this.lbNumHabitacion = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtbEfectivo = new System.Windows.Forms.TextBox();
            this.rdbEfectivo = new System.Windows.Forms.RadioButton();
            this.rdbTarjetacredito = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.lbTotalPagar = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.rbtnNo = new System.Windows.Forms.RadioButton();
            this.rbtnSi = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.CmbNoches = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbNumPersonas
            // 
            this.cmbNumPersonas.Font = new System.Drawing.Font("Segoe Print", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNumPersonas.FormattingEnabled = true;
            this.cmbNumPersonas.Location = new System.Drawing.Point(270, 122);
            this.cmbNumPersonas.Name = "cmbNumPersonas";
            this.cmbNumPersonas.Size = new System.Drawing.Size(121, 27);
            this.cmbNumPersonas.TabIndex = 37;
            // 
            // lbNumNoches
            // 
            this.lbNumNoches.AutoSize = true;
            this.lbNumNoches.Font = new System.Drawing.Font("Segoe Print", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNumNoches.Location = new System.Drawing.Point(404, 288);
            this.lbNumNoches.Name = "lbNumNoches";
            this.lbNumNoches.Size = new System.Drawing.Size(0, 19);
            this.lbNumNoches.TabIndex = 34;
            // 
            // lbNumPersonas
            // 
            this.lbNumPersonas.AutoSize = true;
            this.lbNumPersonas.Font = new System.Drawing.Font("Segoe Print", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNumPersonas.Location = new System.Drawing.Point(403, 128);
            this.lbNumPersonas.Name = "lbNumPersonas";
            this.lbNumPersonas.Size = new System.Drawing.Size(0, 19);
            this.lbNumPersonas.TabIndex = 35;
            // 
            // lbNumHabitacion
            // 
            this.lbNumHabitacion.AutoSize = true;
            this.lbNumHabitacion.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.lbNumHabitacion.Location = new System.Drawing.Point(596, 297);
            this.lbNumHabitacion.Name = "lbNumHabitacion";
            this.lbNumHabitacion.Size = new System.Drawing.Size(37, 21);
            this.lbNumHabitacion.TabIndex = 33;
            this.lbNumHabitacion.Text = "000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.label4.Location = new System.Drawing.Point(414, 297);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 21);
            this.label4.TabIndex = 29;
            this.label4.Text = "Número de habitación:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.label2.Location = new System.Drawing.Point(75, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 21);
            this.label2.TabIndex = 30;
            this.label2.Text = "Habitaciones disponibles";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.label1.Location = new System.Drawing.Point(75, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 21);
            this.label1.TabIndex = 31;
            this.label1.Text = "Número de personas";
            // 
            // txtbEfectivo
            // 
            this.txtbEfectivo.Font = new System.Drawing.Font("Segoe Print", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbEfectivo.Location = new System.Drawing.Point(522, 410);
            this.txtbEfectivo.Name = "txtbEfectivo";
            this.txtbEfectivo.Size = new System.Drawing.Size(148, 27);
            this.txtbEfectivo.TabIndex = 42;
            this.txtbEfectivo.Visible = false;
            // 
            // rdbEfectivo
            // 
            this.rdbEfectivo.AutoSize = true;
            this.rdbEfectivo.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.rdbEfectivo.Location = new System.Drawing.Point(350, 409);
            this.rdbEfectivo.Name = "rdbEfectivo";
            this.rdbEfectivo.Size = new System.Drawing.Size(75, 25);
            this.rdbEfectivo.TabIndex = 43;
            this.rdbEfectivo.TabStop = true;
            this.rdbEfectivo.Text = "Efectivo";
            this.rdbEfectivo.UseVisualStyleBackColor = true;
            // 
            // rdbTarjetacredito
            // 
            this.rdbTarjetacredito.AutoSize = true;
            this.rdbTarjetacredito.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.rdbTarjetacredito.Location = new System.Drawing.Point(350, 386);
            this.rdbTarjetacredito.Name = "rdbTarjetacredito";
            this.rdbTarjetacredito.Size = new System.Drawing.Size(140, 25);
            this.rdbTarjetacredito.TabIndex = 44;
            this.rdbTarjetacredito.TabStop = true;
            this.rdbTarjetacredito.Text = "Tarjeta de Credito";
            this.rdbTarjetacredito.UseVisualStyleBackColor = true;
            this.rdbTarjetacredito.CheckedChanged += new System.EventHandler(this.rdbTarjetacredito_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.label12.Location = new System.Drawing.Point(371, 364);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 21);
            this.label12.TabIndex = 41;
            this.label12.Text = "Método de pago";
            // 
            // lbTotalPagar
            // 
            this.lbTotalPagar.AutoSize = true;
            this.lbTotalPagar.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.lbTotalPagar.Location = new System.Drawing.Point(557, 500);
            this.lbTotalPagar.Name = "lbTotalPagar";
            this.lbTotalPagar.Size = new System.Drawing.Size(46, 21);
            this.lbTotalPagar.TabIndex = 39;
            this.lbTotalPagar.Text = "1000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(374, 500);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 23);
            this.label7.TabIndex = 40;
            this.label7.Text = "Total a pagar";
            // 
            // rbtnNo
            // 
            this.rbtnNo.AutoSize = true;
            this.rbtnNo.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.rbtnNo.Location = new System.Drawing.Point(212, 406);
            this.rbtnNo.Name = "rbtnNo";
            this.rbtnNo.Size = new System.Drawing.Size(48, 25);
            this.rbtnNo.TabIndex = 47;
            this.rbtnNo.TabStop = true;
            this.rbtnNo.Text = "No.";
            this.rbtnNo.UseVisualStyleBackColor = true;
            // 
            // rbtnSi
            // 
            this.rbtnSi.AutoSize = true;
            this.rbtnSi.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.rbtnSi.Location = new System.Drawing.Point(79, 406);
            this.rbtnSi.Name = "rbtnSi";
            this.rbtnSi.Size = new System.Drawing.Size(42, 25);
            this.rbtnSi.TabIndex = 46;
            this.rbtnSi.TabStop = true;
            this.rbtnSi.Text = "Sí.";
            this.rbtnSi.UseVisualStyleBackColor = true;
            this.rbtnSi.Click += new System.EventHandler(this.rbtnSi_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.label6.Location = new System.Drawing.Point(76, 364);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(206, 21);
            this.label6.TabIndex = 45;
            this.label6.Text = "¿Desea algun aperitivo o bebida?";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label25.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(30, 81);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(162, 25);
            this.label25.TabIndex = 51;
            this.label25.Text = "Suites and Resorts";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Font = new System.Drawing.Font("Impact", 31.75F);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(12, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(206, 53);
            this.label5.TabIndex = 49;
            this.label5.Text = "HOTEL  ACA";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.label8.Location = new System.Drawing.Point(541, 500);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 21);
            this.label8.TabIndex = 53;
            this.label8.Text = "$";
            // 
            // CmbNoches
            // 
            this.CmbNoches.Font = new System.Drawing.Font("Segoe Print", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmbNoches.FormattingEnabled = true;
            this.CmbNoches.Location = new System.Drawing.Point(270, 197);
            this.CmbNoches.Name = "CmbNoches";
            this.CmbNoches.Size = new System.Drawing.Size(121, 27);
            this.CmbNoches.TabIndex = 56;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe Print", 9F);
            this.label3.Location = new System.Drawing.Point(75, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 21);
            this.label3.TabIndex = 55;
            this.label3.Text = "Número de noches";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(535, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(134, 113);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 50;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(422, 108);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(68, 52);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 48;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(283, 38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 65);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::HotelProyecto.Properties.Resources.elipse_rojo;
            this.pictureBox5.Location = new System.Drawing.Point(506, 462);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(148, 97);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 52;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::HotelProyecto.Properties.Resources.a5543288429d4df28f62ecef492efcf3;
            this.pictureBox6.Location = new System.Drawing.Point(-2, 123);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(697, 436);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 54;
            this.pictureBox6.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(260, 255);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 43);
            this.button1.TabIndex = 57;
            this.button1.Text = "Checar Disponibilidad";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(422, 197);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(68, 52);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 48;
            this.pictureBox3.TabStop = false;
            // 
            // FormCheck_In
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 564);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CmbNoches);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.rbtnNo);
            this.Controls.Add(this.rbtnSi);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtbEfectivo);
            this.Controls.Add(this.rdbEfectivo);
            this.Controls.Add(this.rdbTarjetacredito);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lbTotalPagar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbNumPersonas);
            this.Controls.Add(this.lbNumNoches);
            this.Controls.Add(this.lbNumPersonas);
            this.Controls.Add(this.lbNumHabitacion);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox6);
            this.Name = "FormCheck_In";
            this.Text = "Check_In";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cmbNumPersonas;
        private System.Windows.Forms.Label lbNumNoches;
        private System.Windows.Forms.Label lbNumPersonas;
        private System.Windows.Forms.Label lbNumHabitacion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbEfectivo;
        private System.Windows.Forms.RadioButton rdbEfectivo;
        private System.Windows.Forms.RadioButton rdbTarjetacredito;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbTotalPagar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rbtnNo;
        private System.Windows.Forms.RadioButton rbtnSi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.ComboBox CmbNoches;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}