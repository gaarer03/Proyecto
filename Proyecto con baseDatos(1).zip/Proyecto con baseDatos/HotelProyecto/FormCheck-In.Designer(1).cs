﻿namespace HotelProyecto
{
    partial class FormCheck_In
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbNumHabitacion = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rbtnSi = new System.Windows.Forms.RadioButton();
            this.rbtnNo = new System.Windows.Forms.RadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.lbTotalPagar = new System.Windows.Forms.Label();
            this.lbNumPersonas = new System.Windows.Forms.Label();
            this.lbNumNoches = new System.Windows.Forms.Label();
            this.cmbNumPersonas = new System.Windows.Forms.ComboBox();
            this.CmbNoches = new System.Windows.Forms.ComboBox();
            this.txtbEfectivo = new System.Windows.Forms.TextBox();
            this.rdbEfectivo = new System.Windows.Forms.RadioButton();
            this.rdbTarjetacredito = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(66, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número de personas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(66, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(165, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Habitaciones disponibles";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(262, 79);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(66, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Número de noches";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(412, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Número de habitación:";
            // 
            // lbNumHabitacion
            // 
            this.lbNumHabitacion.AutoSize = true;
            this.lbNumHabitacion.Location = new System.Drawing.Point(593, 161);
            this.lbNumHabitacion.Name = "lbNumHabitacion";
            this.lbNumHabitacion.Size = new System.Drawing.Size(25, 13);
            this.lbNumHabitacion.TabIndex = 4;
            this.lbNumHabitacion.Text = "000";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label6.Location = new System.Drawing.Point(66, 283);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(221, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "¿Desea algun aperitivo o bebida?";
            // 
            // rbtnSi
            // 
            this.rbtnSi.AutoSize = true;
            this.rbtnSi.Location = new System.Drawing.Point(69, 325);
            this.rbtnSi.Name = "rbtnSi";
            this.rbtnSi.Size = new System.Drawing.Size(39, 17);
            this.rbtnSi.TabIndex = 5;
            this.rbtnSi.TabStop = true;
            this.rbtnSi.Text = "Sí.";
            this.rbtnSi.UseVisualStyleBackColor = true;
            this.rbtnSi.CheckedChanged += new System.EventHandler(this.rbtnSi_CheckedChanged);
            // 
            // rbtnNo
            // 
            this.rbtnNo.AutoSize = true;
            this.rbtnNo.Location = new System.Drawing.Point(202, 325);
            this.rbtnNo.Name = "rbtnNo";
            this.rbtnNo.Size = new System.Drawing.Size(42, 17);
            this.rbtnNo.TabIndex = 6;
            this.rbtnNo.TabStop = true;
            this.rbtnNo.Text = "No.";
            this.rbtnNo.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label7.Location = new System.Drawing.Point(354, 365);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "Total a pagar";
            // 
            // lbTotalPagar
            // 
            this.lbTotalPagar.AutoSize = true;
            this.lbTotalPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbTotalPagar.Location = new System.Drawing.Point(501, 365);
            this.lbTotalPagar.Name = "lbTotalPagar";
            this.lbTotalPagar.Size = new System.Drawing.Size(32, 17);
            this.lbTotalPagar.TabIndex = 0;
            this.lbTotalPagar.Text = "$$$";
            this.lbTotalPagar.Click += new System.EventHandler(this.lbTotalPagar_Click);
            // 
            // lbNumPersonas
            // 
            this.lbNumPersonas.AutoSize = true;
            this.lbNumPersonas.Location = new System.Drawing.Point(394, 34);
            this.lbNumPersonas.Name = "lbNumPersonas";
            this.lbNumPersonas.Size = new System.Drawing.Size(0, 13);
            this.lbNumPersonas.TabIndex = 7;
            // 
            // lbNumNoches
            // 
            this.lbNumNoches.AutoSize = true;
            this.lbNumNoches.Location = new System.Drawing.Point(394, 219);
            this.lbNumNoches.Name = "lbNumNoches";
            this.lbNumNoches.Size = new System.Drawing.Size(0, 13);
            this.lbNumNoches.TabIndex = 7;
            // 
            // cmbNumPersonas
            // 
            this.cmbNumPersonas.FormattingEnabled = true;
            this.cmbNumPersonas.Location = new System.Drawing.Point(261, 28);
            this.cmbNumPersonas.Name = "cmbNumPersonas";
            this.cmbNumPersonas.Size = new System.Drawing.Size(121, 21);
            this.cmbNumPersonas.TabIndex = 8;
            this.cmbNumPersonas.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // CmbNoches
            // 
            this.CmbNoches.FormattingEnabled = true;
            this.CmbNoches.Location = new System.Drawing.Point(261, 211);
            this.CmbNoches.Name = "CmbNoches";
            this.CmbNoches.Size = new System.Drawing.Size(121, 21);
            this.CmbNoches.TabIndex = 8;
            this.CmbNoches.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtbEfectivo
            // 
            this.txtbEfectivo.Location = new System.Drawing.Point(529, 330);
            this.txtbEfectivo.Name = "txtbEfectivo";
            this.txtbEfectivo.Size = new System.Drawing.Size(148, 20);
            this.txtbEfectivo.TabIndex = 24;
            this.txtbEfectivo.Visible = false;
            // 
            // rdbEfectivo
            // 
            this.rdbEfectivo.AutoSize = true;
            this.rdbEfectivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbEfectivo.Location = new System.Drawing.Point(357, 329);
            this.rdbEfectivo.Name = "rdbEfectivo";
            this.rdbEfectivo.Size = new System.Drawing.Size(76, 21);
            this.rdbEfectivo.TabIndex = 25;
            this.rdbEfectivo.TabStop = true;
            this.rdbEfectivo.Text = "Efectivo";
            this.rdbEfectivo.UseVisualStyleBackColor = true;
            // 
            // rdbTarjetacredito
            // 
            this.rdbTarjetacredito.AutoSize = true;
            this.rdbTarjetacredito.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbTarjetacredito.Location = new System.Drawing.Point(357, 306);
            this.rdbTarjetacredito.Name = "rdbTarjetacredito";
            this.rdbTarjetacredito.Size = new System.Drawing.Size(140, 21);
            this.rdbTarjetacredito.TabIndex = 26;
            this.rdbTarjetacredito.TabStop = true;
            this.rdbTarjetacredito.Text = "Tarjeta de Credito";
            this.rdbTarjetacredito.UseVisualStyleBackColor = true;
            this.rdbTarjetacredito.CheckedChanged += new System.EventHandler(this.rdbTarjetacredito_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(354, 287);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 17);
            this.label12.TabIndex = 23;
            this.label12.Text = "Método de pago";
            // 
            // FormCheck_In
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 497);
            this.Controls.Add(this.txtbEfectivo);
            this.Controls.Add(this.rdbEfectivo);
            this.Controls.Add(this.rdbTarjetacredito);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.CmbNoches);
            this.Controls.Add(this.cmbNumPersonas);
            this.Controls.Add(this.lbNumNoches);
            this.Controls.Add(this.lbNumPersonas);
            this.Controls.Add(this.rbtnNo);
            this.Controls.Add(this.rbtnSi);
            this.Controls.Add(this.lbNumHabitacion);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lbTotalPagar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormCheck_In";
            this.Text = "Check_In";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbNumHabitacion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rbtnSi;
        private System.Windows.Forms.RadioButton rbtnNo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbTotalPagar;
        private System.Windows.Forms.Label lbNumPersonas;
        private System.Windows.Forms.Label lbNumNoches;
        private System.Windows.Forms.ComboBox cmbNumPersonas;
        private System.Windows.Forms.ComboBox CmbNoches;
        private System.Windows.Forms.TextBox txtbEfectivo;
        private System.Windows.Forms.RadioButton rdbEfectivo;
        private System.Windows.Forms.RadioButton rdbTarjetacredito;
        private System.Windows.Forms.Label label12;
    }
}